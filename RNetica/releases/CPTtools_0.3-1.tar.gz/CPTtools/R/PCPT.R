### Parameterized Conditional Probability Tables.
### This has the following fields

### type -- a character vector giving the type of the distribution
### name -- an identifier for the distribution
### levels -- a vector of character labels for the states of the child variable.
### parLevels -- a list of vectors of the labeles for the states of the
###   parent variables.  The names of this list should be the parent
###   variable names.
### lnAlphas -- log scale parameters.  This should be either a numeric
###   vector or a list of numeric vectors (with length
###   length(levels)-1).  In either case, the values can be scalar or
###   have length(parLevels)
### betas -- location parameters.  Should follow have one of the same
###   lengths as the lnAlphas
### rules -- a combination function, or a list of combination
###   functions (of length length(levels)-1)
### link -- a link funciton (e.g., gradedResponse, partialCredit or Normal)
### linkVars -- NULL or a vector of variance parameters for the link
###   function.  (use for normal link function)

