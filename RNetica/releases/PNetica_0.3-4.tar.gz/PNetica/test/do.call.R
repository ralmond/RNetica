
grades <-
data.frame(Name=c("Abalard","Balthasar","Casper"),Grade=c(4,3,2),
  stringsAsFactors=FALSE)

checknumrows <- function (X, n, df) {
  if (n != nrow(df))
    stop("Expected ",n,"rows.")
  is.active(X)
}

checknumrows(CM, 3, grades)

do.call("checknumrows",list(CM,3,grades))
