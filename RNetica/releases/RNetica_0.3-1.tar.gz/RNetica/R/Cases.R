## Cases.R -- Functions dealing with cases and case files.


CaseFileDelimiter <- function (newdelimiter=NULL) {
  if (length(newdelimiter)> 1) {
    stop("Only one delimiter allowed.")
  }
  if (!is.null(newdelimiter)) {
    if (!is.character(newdelimiter)) {
      stop("Expected a character, got",newdelimiter)
    }
    if (nchar(newdelimiter)>1) {
      warning("Delimiter has multiple characters, only the first will be used.")
    }
    newdelimiter <- utf8ToInt(newdelimiter)
    if (length(newdelimiter)==0) newdelimiter <- 0
  }
  olddelim <- .Call("RN_CaseFileDelimiter",newdelimiter,PACKAGE="RNetica")
  ecount <- ReportErrors()
  if (ecount[1]>0) {
    stop("CaseFileDelimiter: Netica Errors Encountered, see console for details.")
  }
  intToUtf8(olddelim)
}

CaseFileMissingCode <- function (newcode=NULL) {
  if (length(newcode)> 1) {
    stop("Only one code allowed.")
  }
  if (!is.null(newcode)) {
    if (!is.character(newcode)) {
      stop("Expected a character, got",newcode)
    }
    if (nchar(newcode)>1) {
      warning("Missing code has multiple characters, only the first will be used.")
    }
    if (nchar(newcode)==0) {
      newcode <- 0L
    } else {
      newcode <- utf8ToInt(newcode)
    }
  }
  oldcode <- .Call("RN_MissingCode",newcode,PACKAGE="RNetica")
  ecount <- ReportErrors()
  if (ecount[1]>0) {
    stop("CaseFileMissingCode: Netica Errors Encountered, see console for details.")
  }
  intToUtf8(oldcode)
}

WriteFindingsToFile <- function (nodes,filename,id=-1L,freq=-1L) {
  if (!is.list(nodes) || !all(sapply(nodes,is.NeticaNode)) ||
      !all(sapply(nodes,is.active))) {
    stop("Argument nodes must be a list of active Netica nodes.")
  }
  if (!is.character(filename) || length(filename) >1L) {
    stop("Filename must be a character scalar.")
  }
  id <- as.integer(id)
  if (length(id) >1L) {
    stop("Argument id must be an integer scalar.")
  }
  freq <- as.integer(freq)
  if (length(freq) >1L) {
    stop("Argument freq must be an integer scalar.")
  }
  .Call("RN_WriteFindingsToFile",nodes,filename,id,freq,PACKAGE="RNetica")
  ecount <- ReportErrors()
  if (ecount[1]>0) {
    stop("WriteFindingsToFile: Netica Errors Encountered, see console for details.")
  }
  invisible(NULL)
}
